package org.sang.yun.pojo;

public class User {
    private Integer id;

    private String adCompanyName;

    private String clName;

    private String clPhone;

    private String clLogin;

    private Integer roleId;

    private Integer clNumber;

    private String clWareHouse;

    private Integer clAreal;

    private String clRegion;

    private String clAddress;

    private Integer clPostCode;

    private Integer clAdId;

    private String clMassageq;

    private String clFile;

    private String clContacts;

    private String clPosition;

    private String clTelephone;

    private String clEmail;

    private String clQQ;

    private Integer clStatus;

    private String clPassWord;

    private Integer clType;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAdCompanyName() {
        return adCompanyName;
    }

    public void setAdCompanyName(String adCompanyName) {
        this.adCompanyName = adCompanyName == null ? null : adCompanyName.trim();
    }

    public String getClName() {
        return clName;
    }

    public void setClName(String clName) {
        this.clName = clName == null ? null : clName.trim();
    }

    public String getClPhone() {
        return clPhone;
    }

    public void setClPhone(String clPhone) {
        this.clPhone = clPhone == null ? null : clPhone.trim();
    }

    public String getClLogin() {
        return clLogin;
    }

    public void setClLogin(String clLogin) {
        this.clLogin = clLogin == null ? null : clLogin.trim();
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getClNumber() {
        return clNumber;
    }

    public void setClNumber(Integer clNumber) {
        this.clNumber = clNumber;
    }

    public String getClWareHouse() {
        return clWareHouse;
    }

    public void setClWareHouse(String clWareHouse) {
        this.clWareHouse = clWareHouse == null ? null : clWareHouse.trim();
    }

    public Integer getClAreal() {
        return clAreal;
    }

    public void setClAreal(Integer clAreal) {
        this.clAreal = clAreal;
    }

    public String getClRegion() {
        return clRegion;
    }

    public void setClRegion(String clRegion) {
        this.clRegion = clRegion == null ? null : clRegion.trim();
    }

    public String getClAddress() {
        return clAddress;
    }

    public void setClAddress(String clAddress) {
        this.clAddress = clAddress == null ? null : clAddress.trim();
    }

    public Integer getClPostCode() {
        return clPostCode;
    }

    public void setClPostCode(Integer clPostCode) {
        this.clPostCode = clPostCode;
    }

    public Integer getClAdId() {
        return clAdId;
    }

    public void setClAdId(Integer clAdId) {
        this.clAdId = clAdId;
    }

    public String getClMassageq() {
        return clMassageq;
    }

    public void setClMassageq(String clMassageq) {
        this.clMassageq = clMassageq == null ? null : clMassageq.trim();
    }

    public String getClFile() {
        return clFile;
    }

    public void setClFile(String clFile) {
        this.clFile = clFile == null ? null : clFile.trim();
    }

    public String getClContacts() {
        return clContacts;
    }

    public void setClContacts(String clContacts) {
        this.clContacts = clContacts == null ? null : clContacts.trim();
    }

    public String getClPosition() {
        return clPosition;
    }

    public void setClPosition(String clPosition) {
        this.clPosition = clPosition == null ? null : clPosition.trim();
    }

    public String getClTelephone() {
        return clTelephone;
    }

    public void setClTelephone(String clTelephone) {
        this.clTelephone = clTelephone == null ? null : clTelephone.trim();
    }

    public String getClEmail() {
        return clEmail;
    }

    public void setClEmail(String clEmail) {
        this.clEmail = clEmail == null ? null : clEmail.trim();
    }

    public String getClQQ() {
        return clQQ;
    }

    public void setClQQ(String clQQ) {
        this.clQQ = clQQ == null ? null : clQQ.trim();
    }

    public Integer getClStatus() {
        return clStatus;
    }

    public void setClStatus(Integer clStatus) {
        this.clStatus = clStatus;
    }

    public String getClPassWord() {
        return clPassWord;
    }

    public void setClPassWord(String clPassWord) {
        this.clPassWord = clPassWord == null ? null : clPassWord.trim();
    }

    public Integer getClType() {
        return clType;
    }

    public void setClType(Integer clType) {
        this.clType = clType;
    }
}